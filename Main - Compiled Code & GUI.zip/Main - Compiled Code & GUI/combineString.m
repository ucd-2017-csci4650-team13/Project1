function newString = combineString(currentString, addedString)
newString = sprintf('%s\n%s',currentString, addedString);